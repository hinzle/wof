# env.py

#codeup creds

host = '157.230.209.171'
username = 'innis_1652'
user=username
password = 'o03PdzsGXD30xBXExiXZ3jhL3Q4RMuaE'

def get_db_url(dbname, user=user,host=host,password=password):
	url = f'mysql+pymysql://{user}:{password}@{host}/{dbname}'
	return url


# binance creds

API_KEY = 'yourbinanceapikey'
API_SECRET = 'yourbinanceapisecret'