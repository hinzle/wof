This will be the aqcuire package for my quanto-crypto machine learning guided trading algorithm.
